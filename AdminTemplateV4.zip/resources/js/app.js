import Swiper from "swiper";
import { Navigation, Pagination, Zoom } from "swiper/modules";

import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import "swiper/css/zoom";
// import "flowbite";

window.Swiper = Swiper;
window.Navigation = Navigation;
window.Pagination = Pagination;
window.Zoom = Zoom;

import Alpine from "alpinejs";

window.Alpine = Alpine;

Alpine.start();
import "./customFunctions";
import "./datatableHandler";
import "./apihandler";
import "./customAlert";
import "./navmenu";
// import "./notificationController";
import "./mailer";
import "./toast";

import "./formatter";
import "./logic_crm";
import "./remoteTable";
